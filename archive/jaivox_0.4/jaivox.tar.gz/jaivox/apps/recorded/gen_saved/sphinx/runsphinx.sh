#!/bin/sh

java sphinxTest

