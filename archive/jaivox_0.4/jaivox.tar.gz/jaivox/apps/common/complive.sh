#!/bin/sh

javac -classpath PATfreettsjar:$CLASSPATH PATliveTest.java

