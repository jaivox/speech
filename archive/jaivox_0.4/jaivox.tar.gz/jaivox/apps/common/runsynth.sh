#!/bin/sh

java -classpath PATfreettsjar:$CLASSPATH PATsynthesizerTest

