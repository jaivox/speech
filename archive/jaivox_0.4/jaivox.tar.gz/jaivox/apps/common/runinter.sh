#!/bin/sh

java PATinterpreterTest

