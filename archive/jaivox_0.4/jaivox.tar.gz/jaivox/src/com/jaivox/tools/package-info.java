/**
This package is a tool for generating a complete recognizer/interpreter/
synthesizer solution from some specifications. The tools here generate
the questions and various files needed for speech recognition from a table
that consists of one text field and several numerical "attribute" fields.
*/
package com.jaivox.tools;
