/**
This package contains handlers for http, and fileserver protocols.
Others can be added here (such as a full Json handler.) An Htp server
can be used for instance to respond to spoken queries like searches
with results in a web page.
*/
package com.jaivox.protocol;
