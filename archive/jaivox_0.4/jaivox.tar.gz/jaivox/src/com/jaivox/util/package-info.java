/**
The util package contains a few logging classes.
*/
package com.jaivox.util;