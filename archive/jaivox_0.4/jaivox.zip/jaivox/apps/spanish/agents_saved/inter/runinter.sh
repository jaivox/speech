#!/bin/sh

java interTest

