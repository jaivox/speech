#!/bin/sh

java -classpath /usr/local/freetts/lib/freetts.jar:$CLASSPATH synthesizerTest

