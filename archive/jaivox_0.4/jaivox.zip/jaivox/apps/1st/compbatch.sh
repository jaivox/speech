#!/bin/sh

javac -classpath /usr/local/freetts/lib/freetts.jar:$CLASSPATH batchTest.java

