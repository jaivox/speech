#!/bin/sh

javac -classpath PATfreettsjar:$CLASSPATH PATsynthesizerTest.java

