#!/bin/sh

java PATrecognizerTest

