#!/bin/sh

javac -classpath PATfreettsjar:$CLASSPATH PATbatchTest.java

