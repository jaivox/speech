/**
This package utilizes the Sphinx libraries to recognize spoken
sentences.
*/
package com.jaivox.recognizer.sphinx;
